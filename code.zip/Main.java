public class Main {
    public Main() {
    }

    public static void main(String[] args) throws Exception {
//        StartFrame sf = new StartFrame();
        //新建游戏窗口
        GameFrame gf = new GameFrame();
        //新建按键监听器
        KeyListener kl = new KeyListener(gf);
        //按键监听器向游戏窗口注册
        gf.addKeyListener(kl);
    }
}